//
//  ViewController.swift
//  TabbarBasic
//
//  Created by 1v1 on 2021/01/08.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

