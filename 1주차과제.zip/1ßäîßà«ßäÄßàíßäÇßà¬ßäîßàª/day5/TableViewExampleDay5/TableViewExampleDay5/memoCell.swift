//
//  memoCell.swift
//  TableViewExampleDay5
//
//  Created by 1v1 on 2021/01/11.
//

import UIKit
class memoCell: UITableViewCell {
    
    @IBOutlet weak var numLabel: UILabel!
    @IBOutlet weak var memoLabel: UILabel!
}
