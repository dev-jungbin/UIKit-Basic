//
//  Cell.swift
//  AlamofireBasic
//
//  Created by 1v1 on 2021/01/18.
//

import UIKit
class Cell: UITableViewCell {
    
    @IBOutlet weak var label: UILabel!
}
