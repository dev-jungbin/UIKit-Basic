//
//  structs.swift
//  AlamofireBasic
//
//  Created by 1v1 on 2021/01/18.
//

struct DummyData:Codable {
    let userId:Int
    let id:Int
    let title:String
    let body:String
}

struct PersonInfo:Codable {
    
}
