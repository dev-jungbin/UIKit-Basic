//
//  LottoCell.swift
//  LottoDraw
//
//  Created by 1v1 on 2021/01/07.
//

import UIKit

class LottoCell:UITableViewCell{
    
    @IBOutlet weak var number1: UILabel!
    @IBOutlet weak var number2: UILabel!
    @IBOutlet weak var number3: UILabel!
    @IBOutlet weak var number4: UILabel!
    @IBOutlet weak var number5: UILabel!
    @IBOutlet weak var number6: UILabel!
}
